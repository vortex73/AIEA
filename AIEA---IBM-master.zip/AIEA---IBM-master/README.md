# AIEA---IBM
It is a project which can identify an accident using (IBM Watson Visual Recognition)from real time footage and send information of the accident like location to the closest hospital via whatsapp

-----------INSTRUCTIONS--------------

Prerequisite modules and  API Keys:

main.py:

1)keyboard module

whatsapp.py:

1)TWILIO module

watson_api.py:

1) ibm_watson module

2)IAM Authentication module

3)API Key for IBM Watson

tomtom(1).py:

1)requests module

2)configparser module

3)TomTom API Key

-----TO RUN-----
before running main.py change the path location in the code for it to store the images

run main.py
