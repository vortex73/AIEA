# the dictionary 

d = {'Samastha hospital':[12.897705, 77.545360],'Mantri Mall':[12.991892, 77.571580],'Delhi Public School':[12.893478, 77.563568],'Swestha Enterprises':[12.988076, 77.563962],'Apollo Pharmacy':[12.992608, 77.565534]}
